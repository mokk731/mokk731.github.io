document.addEventListener("iaddfgegjgjelgkanamleadckkpnjpjc_qualitysetter", function(_e) {
  chrome.storage.local.get(["quality"]).then((result) => {
    if (result.quality !== "undefined") {
      letMainChangeQuality(result.quality);
    }
  });
});
document.addEventListener("iaddfgegjgjelgkanamleadckkpnjpjc_autopauser", function(_e) {
  chrome.storage.local.get(["autopause"]).then((result) => {
    if (result.autopause !== "undefined") {
      letMainChangeAutopause(result.autopause);
    }
  });
});

chrome.runtime.onMessage.addListener((request, _sender, _sendResponse) => {
  switch (request.action) {
    case "settingsChanged":
      letMainChangeQuality(request.quality);
      letMainChangeAutopause(request.autopause);
      break;
    case "qualityListUpdated":
      sendQualityList(request.data);
      break;
    case "aqfy1":
      document.dispatchEvent(
        new CustomEvent(request.action, { detail: request.detail })
      )
      break;
  }
});

const letMainChangeQuality = (quality) => {
  document.dispatchEvent(
    new CustomEvent("iaddfgegjgjelgkanamleadckkpnjpjc_setquality", {
      detail: { quality: quality },
    })
  );
};

const letMainChangeAutopause = (autopause) => {
  document.dispatchEvent(
    new CustomEvent("iaddfgegjgjelgkanamleadckkpnjpjc_setautopause", {
      detail: { autopause: autopause },
    })
  );
};

const sendQualityList = (data) => {
  document.dispatchEvent(
    new CustomEvent("iaddfgegjgjelgkanamleadckkpnjpjc_qualitylist", {
      detail: { data: data },
    })
  );
};
