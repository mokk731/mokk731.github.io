let alreadyPaused = false;
const initListener = () => {
  window.addEventListener("loadstart", iaddfgegjgjelgkanamleadckkpnjpjc_onYouTubeLoadstart, true);

  document.addEventListener("iaddfgegjgjelgkanamleadckkpnjpjc_setquality", (e) => {
    const player = iaddfgegjgjelgkanamleadckkpnjpjc_getPlayer();
    if (player && player.getPlaybackQuality() !== e.detail.quality) {
      console.log("setting video quality", e.detail.quality);
      player.setPlaybackQualityRange(e.detail.quality);
    }
  });

  document.addEventListener("iaddfgegjgjelgkanamleadckkpnjpjc_setautopause", (e) => {
    const player = iaddfgegjgjelgkanamleadckkpnjpjc_getPlayer()
    if (player && e.detail.autopause === true) {
      player.pauseVideo()
    }
  });

  window.addEventListener("loadstart", () => {
    const player = iaddfgegjgjelgkanamleadckkpnjpjc_getPlayer()
    if (player) {
      player.addEventListener("onStateChange", function(state) { ytpStateChangedHandler(player, state); }, true);
    }
  }, true)
};

const iaddfgegjgjelgkanamleadckkpnjpjc_onYouTubeLoadstart = () => {
  let player = iaddfgegjgjelgkanamleadckkpnjpjc_getPlayer();

  if (player) {
    document.dispatchEvent(
      new CustomEvent("iaddfgegjgjelgkanamleadckkpnjpjc_qualitysetter", {
        detail: {},
      })
    );
    document.dispatchEvent(
      new CustomEvent("iaddfgegjgjelgkanamleadckkpnjpjc_autopauser", {
        detail: {},
      })
    );
  }
};

function ytpStateChangedHandler(_player, state) {
  switch (state) {
    case 2:
      alreadyPaused = true
  }

  if (!alreadyPaused) {
    document.dispatchEvent(
      new CustomEvent("iaddfgegjgjelgkanamleadckkpnjpjc_autopauser", {
        detail: {}
      })
    )
  }
}

const iaddfgegjgjelgkanamleadckkpnjpjc_getPlayer = () => {
  var p = null;
  if (window.videoPlayer) {
    for (var i in window.videoPlayer) {
      if (window.videoPlayer[i] && window.videoPlayer[i].setPlaybackQuality) {
        p = window.videoPlayer[i];
        break;
      }
    }
  } else {
    p =
      document.getElementById("movie_player") ||
      document.getElementsByClassName("html5-video-player")[0] ||
      document.getElementById("movie_player-flash") ||
      document.getElementById("movie_player-html5") ||
      document.getElementById("movie_player-html5-flash");
  }
  return p;
};

if (
  top.location.href.match("^((http|https)://)*(www.|gaming.)*youtube.com(.*)$")
) {
  initListener();
}
