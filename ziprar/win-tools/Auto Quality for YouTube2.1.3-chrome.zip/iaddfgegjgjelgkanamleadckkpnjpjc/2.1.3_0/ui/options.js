let statusTimeout;

function saveOptions() {
  var quality = document.getElementById("quality").value;
  var autopause = document.getElementById("autopause").checked;

  chrome.storage.local
    .set({ quality, autopause })
    .then(() => {
      chrome.tabs.query({}, (tabs) => {
        tabs.forEach((tab) => {
          chrome.tabs.sendMessage(
            tab.id,
            {
              action: "settingsChanged",
              quality,
              autopause
            },
            (_response) => {
              if (chrome.runtime.lastError) {
                return;
              }
            }
          );
        });
      });

      var status = document.getElementById("status");
      status.textContent = "Options Saved.";
      status.classList.add("status-visible");

      if (statusTimeout) {
        clearTimeout(statusTimeout)
      }

      statusTimeout = setTimeout(function() {
        status.classList.remove("status-visible");
        status.textContent = "";
      }, 4000);
    })
    .catch((error) => {
      console.error("Save error!", error);
    });
}

function loadSettings() {
  chrome.storage.local
    .get(["qualityList", "quality", "autopause"])
    .then((result) => {
      result.qualityList = [];
      if (result.qualityList && result.qualityList !== undefined && result.qualityList.length > 0) {
        document.getElementById("quality").innerHTML = "";
        result.qualityList.forEach((option) => {
          const [key, value] = Object.entries(option)[0];
          const optionElement = document.createElement("option");
          optionElement.value = key;
          optionElement.textContent = value;
          document.getElementById("quality").appendChild(optionElement);
        });
      }
      if (result.quality !== undefined) {
        document.getElementById("quality").value = result.quality;
      }
      if (result.autopause !== undefined) {
        document.getElementById("autopause").checked = result.autopause;
      }
    })
    .catch((error) => console.error("Load error!", error));
}
document.addEventListener("DOMContentLoaded", loadSettings);
document.getElementById("quality").addEventListener("change", saveOptions);
document.getElementById("autopause").addEventListener("change", saveOptions);
