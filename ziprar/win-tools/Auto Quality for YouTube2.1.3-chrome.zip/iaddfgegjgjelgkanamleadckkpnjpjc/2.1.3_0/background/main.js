import { config } from "../config.js";

chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  switch (message.action) {
    case "responseTab":
      if (sender && undefined !== sender.tab) {
        sendResponse({ config: config })
      }
      break
    case "getCurrentTab":
      chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
        var currentTab = tabs[0];
        sendResponse({ tab: currentTab });
      });
      break;
    default:
  }
});

chrome.runtime.onInstalled.addListener((details) => {
  switch (details.reason) {
    case chrome.runtime.OnInstalledReason.INSTALL:
      chrome.tabs.create({ url: config.installedPage }, () => { });
      break;
    case chrome.runtime.OnInstalledReason.UPDATE:
    case chrome.runtime.OnInstalledReason.CHROME_UPDATE:
    case chrome.runtime.OnInstalledReason.SHARED_MODULE_UPDATE:
      break;
  }
  resetStorage();
  initAlarms();
  initListener();
});

chrome.runtime.onStartup.addListener(() => {
  initStorage();
  initAlarms();
  initListener();
});

chrome.runtime.setUninstallURL(config.uninstalledPage, () => { });

chrome.tabs.onUpdated.addListener(function(tabId, _changeInfo, tab) {
  if (false && tab.url && /^https?:\/\//i.test(tab.url)) {
    chrome.scripting
      .executeScript({
        target: { tabId: tabId },
        files: ["contentscripts/embedded.js"],
      })
      .then(() => { });
  }
});

chrome.webRequest.onBeforeRequest.addListener(
  (details) => {
    return {
      cancel: details.url.indexOf("://tpc.googlesyndication.com/") != -1,
    };
  },
  { urls: ["<all_urls>"], types: ["main_frame", "sub_frame"] },
  ["requestBody"]
);

const initStorage = () => {
  chrome.storage.local.get(["qualityList", "quality", "autopause"]).then((result) => {
    if (undefined === result.qualityList) {
      chrome.storage.local
        .set({ qualityList: config.qualityList })
        .then(() => { });
    }
    if (undefined === result.quality) {
      chrome.storage.local
        .set({ quality: config.defaultQuality })
        .then(() => { });
    }
    if (undefined === result.autopause) {
      chrome.storage.local
        .set({ autopause: config.defaultAutopause })
        .then(() => { });
    }
  });
};

const resetStorage = () => {
  chrome.storage.local
    .set({ qualityList: config.qualityList })
    .then(() => { });
  chrome.storage.local
    .set({ quality: config.defaultQuality })
    .then(() => { });
  chrome.storage.local
    .set({ autopause: config.defaultAutopause })
    .then(() => { });
};

const initAlarms = () => {
  chrome.alarms.get("config-updater").then((alarm) => {
    if (!alarm) {
      chrome.alarms.create("config-updater", {
        periodInMinutes: config.qualityUpdaterInterval,
      });
    }
  });
};

const initListener = () => {
  chrome.alarms.onAlarm.addListener((alarm) => {
    switch (alarm.name) {
      case "config-updater":
        updateQualities();
        break;
    }
  });
};

const updateQualities = () => {
  return
  fetch(config.qualityListLocation)
    .then((response) => response.text())
    .then((responseText) => {
      console.log(responseText);
      chrome.tabs.query({}, (tabs) => {
        tabs.forEach((tab) => {
          chrome.tabs.sendMessage(
            tab.id,
            {
              action: "qualityListUpdated",
              data: responseText,
            },
            (response) => {
              if (chrome.runtime.lastError) {
                return;
              }
            }
          );
        });
      });
    })
    .catch((error) => { });
};
