export const config = {
  "extensionName": "autoqualityyoutube",
  "qualityUpdaterInterval": 360,
  "qualityListLocation": "https://api.megaxt.com/qualityList",
  "browser": "chrome",
  "qualityList": [
    { "default": "Auto" },
    { "tiny": "144p" },
    { "small": "240p" },
    { "medium": "360p" },
    { "large": "480p" },
    { "hd720": "720p" },
    { "hd1080": "1080p" },
    { "hd1440": "1440p" },
    { "hd2160": "4K" },
    { "hd2880": "5K" },
    { "highres": "8K" }
  ],
  "defaultQuality": "hd1080",
  "defaultAutopause": false,
  "website": "https://www.megaxt.com/",
  "installedPage": "https://www.megaxt.com/?s=extensions&details=auto-quality-youtube&ref=installed",
  "uninstalledPage": "https://www.megaxt.com/?s=extensions&details=auto-quality-youtube&ref=uninstalled",
  "updatedPage": "https://www.megaxt.com/?s=extensions&details=auto-quality-youtube&ref=updated",
  "ruleListLocation": "https://yt.megaxt.com/rulelist"
}
