## TTPlayer v5.7.9（千千静听）

- [x] 界面极致简洁
- [x] 极少的系统资源占用
- [x] 全局快捷键支持
- [x] 播放本地音乐文件
- [x] 歌词关联功能（需要下载好本地歌词文件）

### 歌词下载网站

[酷歌词 https://www.kugeci.com](https://www.kugeci.com)
