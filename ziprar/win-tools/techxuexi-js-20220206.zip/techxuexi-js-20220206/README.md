# techxuexi-js

**[交流群地址及说明（点击查看）](https://github.com/TechXueXi/TechXueXi/issues/14)**

**我们随时删库跑路，请加交流群防失联。**

有建议说上传到 greasyfork，方便更新。其实，我们在这里发布，是因为有同志发现 greasyfork **有审查**，上传就被举报，被封，**都没有地方可以下载**，所以在这里开库收集的。**该同志表示： 习惯在 greasyfork 找强国佛系xx的人，太年轻了，还不知道社会的险恶**

收集油猴等插件的科技强国 js 代码。

这里没有各种恶心的审查，欢迎大家提交贡献，比如新增脚本，修改代码等。

提交贡献方法： https://github.com/TechXueXi/TechXueXi/blob/dev/CONTRIBUTING.md

## 使用方法

请优先使用 不学习何以强国 ，它可以全自动，以后维护工作以它为主， 强国学习 需要手动进入答题。

装个浏览器插件 tampermonkey （可以从这里下载 https://github.com/TechXueXi/Tampermonkey ，网上也很多教程），点击插件里添加按钮，去掉编辑框里原来的代码，把 不学习何以强国 js 脚本复制粘贴进编辑框保存。开启这个脚本，然后进入网页强国 www.xuexi.cn 登录，刷新登录网页，左上角有启动按钮。

### 如何设置自动升级？

看图：

![image](https://user-images.githubusercontent.com/86897692/149704031-d69cc183-ff29-40a0-94d4-a74f1d2a0edc.png)

![image](https://user-images.githubusercontent.com/86897692/149704044-2fb0c908-c312-42a1-9b14-1a71411b54fe.png)


## 不想每天开电脑学习，可以配置 techxuexi python 在服务器。  https://github.com/TechXueXi/TechXueXi
